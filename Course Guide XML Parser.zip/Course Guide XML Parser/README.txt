courseguideparser
=================
*****************
* Author: Garret Handel
* Last Updated: 2014/02/10
*****************


Python Script to parse an XML file of the UW-Madison course list and output a CSV includeing
the course title, course number, and associated divison and department.

To use:

1) Download course listing from this page: http://registrar.wisc.edu/schedule_of_classes_students.htm

2) Open the file in Adobe Acrobat Pro and export the document as an XML file. 
	(Or you can use another converter to get the XML, I just can't guaruntee this script will work with it.)

3) Copy the file imto the "Course Guide Parser" folder.

4) Run the file "course_guide_xml_parser.exe" The CSV file should appear shortly.